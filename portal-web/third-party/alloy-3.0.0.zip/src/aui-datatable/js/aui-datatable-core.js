A.DataTable.NAME = 'datatable';
A.DataTable.CSS_PREFIX = 'table';
